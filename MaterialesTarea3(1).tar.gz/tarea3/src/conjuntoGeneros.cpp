#include "../include/conjuntoGeneros.h"

struct rep_conjuntogeneros{

};

TConjuntoGeneros crearTConjuntoGeneros(int cantMax){
  return NULL;    
}

bool esVacioTConjuntoGeneros(TConjuntoGeneros c){
  return true;
}

void insertarTConjuntoGeneros(TConjuntoGeneros &c, int id){

}

void borrarDeTConjuntoGeneros(TConjuntoGeneros &c, int id){

}

bool perteneceTConjuntoGeneros(TConjuntoGeneros c, int id){
  return true;
}

int cardinalTConjuntoGeneros(TConjuntoGeneros c){
  return 0;
}

int cantMaxTConjuntoGeneros(TConjuntoGeneros c){
  return 0;
}

void imprimirTConjuntoGeneros(TConjuntoGeneros c){

}

void liberarTConjuntoGeneros(TConjuntoGeneros &c){

}

TConjuntoGeneros unionTConjuntoGeneros(TConjuntoGeneros c1, TConjuntoGeneros c2){
  return NULL;
}

TConjuntoGeneros interseccionTConjuntoGeneros(TConjuntoGeneros c1, TConjuntoGeneros c2){
  return NULL;
}

TConjuntoGeneros diferenciaTConjuntoGeneros(TConjuntoGeneros c1, TConjuntoGeneros c2){
  return NULL;
}
